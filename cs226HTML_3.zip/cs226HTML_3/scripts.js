document.addEventListener('DOMContentLoaded', () => {
    const dropdownHTML = `
        <div style="position: relative;">
            <img src="img/option.png" alt="Options" onclick="toggleDropdown()">
        </div>
        <div id="dropdownMenu">
            <div style="text-align: center; margin-bottom: 10px;">
                <label for="ratingFilter">Select Rating</label>
                <select id="ratingFilter">
                    <option value="5">★★★★★</option>
                    <option value="4">★★★★☆</option>
                    <option value="3">★★★☆☆</option>
                    <option value="2">★★☆☆☆</option>
                    <option value="1">★☆☆☆☆</option>
                </select>
            </div>
            <div class="grid">
                <a href="#" onclick="redirectToPage('Restaurants')">
                    <img src="img/restaurant.png" alt="Restaurants">
                    <div>Restaurants</div>
                </a>
                <a href="#" onclick="redirectToPage('Shopping')">
                    <img src="img/shopping.png" alt="Shopping">
                    <div>Shoopping</div>
                </a>
                <a href="#" onclick="redirectToPage('CoffeeTea')">
                    <img src="img/coffee.png" alt="Coffee & Tea">
                    <div>Coffee & Tea</div>
                </a>
                <a href="#" onclick="redirectToPage('EventPlanning')">
                    <img src="img/plan.png" alt="Event Planning & Services">
                    <div>Event Planning & Services</div>
                </a>
                <a href="#" onclick="redirectToPage('HealthMedical')">
                    <img src="img/health.png" alt="Health & Medical">
                    <div>Health & Medical</div>
                </a>
            </div>
        </div>
    `;
    document.getElementById('dropdown-container').innerHTML = dropdownHTML;

    // Toggle Dropdown Visibility
    window.toggleDropdown = () => {
        const menu = document.getElementById('dropdownMenu');
        menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    };

    // Redirect to the appropriate page
    window.redirectToPage = (category) => {
        const selectedRating = document.getElementById('ratingFilter').value;
        const url = `high_rating_${selectedRating}_${category}_map.html`;
        window.location.href = url;
    };
});
